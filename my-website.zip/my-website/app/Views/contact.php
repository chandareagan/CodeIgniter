<!DOCTYPE html>
<html>
<head>
    <title>About Us</title>
    <style>
        /* Internal CSS for styling */
        form {
            max-width: 400px;
            margin: 0 auto;
            padding: 20px;
            background-color: #f3f3f3;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        
        nav {
            background-color: #333;
            color: #fff;
            padding: 10px;
        }

        nav a {
            color: #fff;
            text-decoration: none;
            margin-right: 20px;
        }

        input[type="text"],
        input[type="email"],
        textarea {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        input[type="submit"] {
            background-color: #007BFF;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <nav>
        <a href="/">Home</a>
        <a href="/about">About Us</a>
        <a href="/contact">Contact Us</a>
        <a href="/upload">Upload Data</a>
    </nav>
    <h1>About Our Company</h1>
    <p>Our company's goal is to provide high-quality software solutions that meet our client's needs.</p>
    
    <h2>Contact Us</h2>
    <form action="/submit" method="post">
        <label for="name">Name:</label>
        <input type="text" id="name" name="name" required>

        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required>

        <label for="message">Message:</label>
        <textarea id="message" name="message" rows="4" required></textarea>

        <input type="submit" value="Submit">
    </form>
</body>
</html>
