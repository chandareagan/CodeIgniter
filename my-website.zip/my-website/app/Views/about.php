<!DOCTYPE html>
<html>
<head>
    <title>About Us</title>
    <style>
        /* Internal CSS for styling */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
        }
        nav {
            background-color: #333;
            color: #fff;
            padding: 10px;
        }

        nav a {
            color: #fff;
            text-decoration: none;
            margin-right: 20px;
        }


        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
        }

        h1 {
            color: #333;
        }

        p {
            color: #666;
        }

        .feature {
            margin: 20px 0;
            display: flex;
            align-items: center;
        }

        .feature img {
            width: 100px;
            height: 100px;
            margin-right: 20px;
        }

        .feature h2 {
            color: #333;
            font-size: 20px;
        }

        .feature p {
            color: #666;
        }
    </style>
</head>
<body>
    <nav>
        <a href="/">Home</a>
        <a href="/about">About Us</a>
        <a href="/contact">Contact Us</a>
        <a href="/upload">Upload Data</a>
    </nav>
    <div class="container">
        <h1>About Our Company</h1>
        <p>Our company is dedicated to software development and aims to provide innovative solutions that help businesses thrive. Here are some key features that define us:</p>

        <div class="feature">
            <img src="software-development.png" alt="Software Development Icon">
            <h2>Custom Software Development</h2>
            <p>We specialize in creating custom software solutions tailored to the unique needs of our clients.</p>
        </div>

        <div class="feature">
            <img src="innovation.png" alt="Innovation Icon">
            <h2>Innovation</h2>
            <p>We are committed to staying at the forefront of technology and delivering cutting-edge solutions.</p>
        </div>

        <div class="feature">
            <img src="team.png" alt="Expert Team Icon">
            <h2>Expert Team</h2>
            <p>Our team of experienced professionals is passionate about delivering high-quality software products.</p>
        </div>
    </div>
</body>
</html>
