<!DOCTYPE html>
<html>
<head>
    <title>Home</title>
    <style>
        /* Internal CSS for styling */
        body {
            font-family: Arial, sans-serif;
        }

        nav {
            background-color: #333;
            color: #fff;
            padding: 10px;
        }

        nav a {
            color: #fff;
            text-decoration: none;
            margin-right: 20px;
        }

        h1 {
            text-align: center;
            margin-top: 30px;
        }

        #company-image {
            display: block;
            margin: 0 auto;
            width: 200px; /* Adjust the image size as needed */
        }

        #testimonies {
            margin: 30px 0;
            text-align: center;
        }

        #testimonies h2 {
            font-size: 24px;
        }

        #testimonies p {
            font-style: italic;
        }

        #what-we-develop {
            text-align: center;
            margin-top: 30px;
        }
    </style>
</head>
<body>
    <nav>
        <a href="/">Home</a>
        <a href="/about">About Us</a>
        <a href="/contact">Contact Us</a>
        <a href="/upload">Upload Data</a>
    </nav>
    <h1>Welcome to Our Technology Company</h1>
    
    <!-- Company Image -->
    <img id="company-image" src="/path/to/company.jpg" alt="Company Logo">

    <!-- Testimonies -->
    <div id="testimonies">
        <h2>Testimonies from Our Clients</h2>
        <p>Our clients love the software solutions we've provided them with. Here are some of their thoughts:</p>
        <p>"The software developed by this company has transformed our business."</p>
        <p>"I highly recommend their services. Quality and reliability are their strengths."</p>
        <!-- Add more testimonies as needed -->
    </div>

    <!-- What We Develop -->
    <div id="what-we-develop">
        <h2>What We Develop</h2>
        <p>We specialize in a variety of software solutions, including:</p>
        <ul>
            <li>Mobile Apps</li>
            <li>Websites</li>
            <li>Systems</li>
            <li>Cloud-Based Software</li>
        </ul>
    </div>
</body>
</html>
