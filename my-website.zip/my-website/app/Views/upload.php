<!DOCTYPE html>
<html>
<head>
    <title>Upload Data</title>
    <style>
        /* Internal CSS for styling */
        form {
            max-width: 400px;
            margin: 0 auto;
            padding: 20px;
            background-color: #f3f3f3;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        nav {
            background-color: #333;
            color: #fff;
            padding: 10px;
        }

        nav a {
            color: #fff;
            text-decoration: none;
            margin-right: 20px;
        }   

        input[type="text"] {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        input[type="submit"] {
            background-color: #007BFF;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <nav>
        <a href="/">Home</a>
        <a href="/about">About Us</a>
        <a href="/contact">Contact Us</a>
        <a href="/upload">Upload Data</a>
    </nav>
    <h1>Upload Data</h1>
    <form action="/submit" method="post">
        <label for="name">Name:</label>
        <input type="text" id="name" name="name" required>

        <label for="phoneNumber">Phone Number:</label>
        <input type="text" id="phoneNumber" name="phoneNumber" required>

        <label for="email">Email:</label>
        <input type="text" id="email" name="email" required>

        <input type="submit" value="Upload">
    </form>
</body>
</html>
